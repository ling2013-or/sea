<?php
namespace Common\Library\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{

}
