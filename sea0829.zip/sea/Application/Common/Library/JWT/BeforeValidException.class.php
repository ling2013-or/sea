<?php
namespace Common\Library\JWT;

class BeforeValidException extends \UnexpectedValueException
{

}
