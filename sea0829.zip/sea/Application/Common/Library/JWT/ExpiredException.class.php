<?php
namespace Common\Library\JWT;

class ExpiredException extends \UnexpectedValueException
{

}
