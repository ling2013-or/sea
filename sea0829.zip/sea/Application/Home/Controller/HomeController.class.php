<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/8/24
 * Time: 9:53
 */

namespace Home\Controller;


use Think\Controller;

class HomeController extends Controller
{
    /**
     * 加载预处理
     */
    protected function _initialize(){
        //获取配置文件


    }

    /**
     * 判断用户是否登录
     */
    protected function isLogin(){
        
    }


    /**
     * 获取页面轮播图
     * @param $controller
     * @param $method
     * @return array|mixed
     */
    public function getCarousel($controller, $method)
    {
        //获取首页轮播图片信息、活动页面信息
        $data = S($controller . '__' . $method);
        if (!$data) {
            $model = D('Carousel');
            //轮播图
            $map = [];
            $map['model'] = $controller . '/' . $method;;
            $map['status'] = 1;
            $map['type'] = 0;
            $carousel = $model->field('*')->where($map)->find();
            $carousel['img'] = json_decode($carousel['img'], true);
            //获取了轮播图片的个数
            $num = count($carousel);
            $data = [
                //轮播图
                'carousel' => $carousel,
                //轮播图数量
                'num' => $num,
            ];
            S('HOME_DATA_MORE', $data);
        }
        return $data;
    }


    /**
     * 操作错误跳转的快捷方法
     * @access protected
     * @param string $message 错误信息
     * @param string $jumpUrl 页面跳转地址
     * @param mixed $ajax 是否为Ajax方式 当数字时指定跳转时间
     * @return void
     */
    protected function error($message = '', $jumpUrl = '', $ajax = false)
    {
//        D('AdminOperateLog')->record($message, 0);
        parent::error($message, $jumpUrl, $ajax);
    }

    /**
     * 操作成功跳转的快捷方法
     * @access protected
     * @param string $message 提示信息
     * @param string $jumpUrl 页面跳转地址
     * @param mixed $ajax 是否为Ajax方式 当数字时指定跳转时间
     * @return void
     */
    protected function success($message = '', $jumpUrl = '', $ajax = false)
    {
//        D('AdminOperateLog')->record($message, 1);
        parent::success($message, $jumpUrl, $ajax);
    }
} 