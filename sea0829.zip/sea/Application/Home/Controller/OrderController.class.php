<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/8/24
 * Time: 10:55
 */

namespace Home\Controller;


class OrderController extends HomeController{
    public function _initialize(){
        parent::_initialize();
        $this->isLogin();
    }
} 