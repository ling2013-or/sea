<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/8/29
 * Time: 11:17
 */

namespace Home\Controller;


class ShopController extends HomeController{

    //记录用户所选产品信息
    public function add(){
        if(IS_POST){
            //获取产品
            $post = I('post.');
            $map = array();
            $map['id'] = $post['id'];
            $map['goods_type'] = $post['type'];
            $map['status'] =  1;
            $info = M('Goods')->field('id,name,price,picture')->where($map)->find();
            $info['number'] = $post['variety'];
            session('cart.goods',$info);
            //跳转到用户选择订单信息的地址,并选择支付方式
//            $this->redirect('Index/index');
            echo "<pre>";
            print_r($_POST);die;
            print_r(session());die;
        }
    }
} 