<?php
namespace Home\Controller;

use Think\Controller;

/**
 * 个人中心
 * Class PublicController
 * @package Home\Controller
 */
class UserController extends Controller
{



    /**
     * 用户中心
     */
    public function userCenter()
    {
        $this->display();
    }







}