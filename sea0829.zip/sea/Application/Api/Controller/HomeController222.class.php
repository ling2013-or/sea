<?php

namespace Api\Controller;

/**
 * 展示首页推荐产品
 * Class FeedbackController
 * @package Api\Controller
 */
class HomeController extends ApiController
{

    /**
     * 查询当前模块信息
     */
    public function index()
    {
        $data = $this->getCarousel(CONTROLLER_NAME,ACTION_NAME);

        $this->apiReturn(0, '成功', $data);
    }
}