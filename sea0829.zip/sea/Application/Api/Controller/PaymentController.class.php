<?php
/**
 * 获取系统平台的支付方式
 * User: Administrator
 * Date: 2016/8/23
 * Time: 15:05
 */
namespace Api\Controller;

use Common\Library\Pay\Pay;
use Common\Library\Pay\Pay\Param;
use Think\Controller;

class PaymentController extends Controller
{

    public function test(){
        header('location:'.DOMAIN.'zwx.php/pay/index.html');
    }
    public function index(){
        $order['body'] = '你好';
        $order['fee'] = 1;
        $order['order_id'] = 2016666666894;
        $order['title'] = 'test';
        $this->alipay($order);
    }


    /**
     * 支付宝支付
     *
     * @param $type
     */
    private function alipay($order){
        $config = array(
            // 收款账号邮箱
            'email' => 'wz@scbin.com',
            // 加密key，开通支付宝账户后给予
            'key' => 'rnwn0oocydzzizpbcaut9ey8rxc4lkrw',
            // 合作者ID，支付宝有该配置，开通易宝账户后给予
            'partner' => '2088311603328755',
            'private_key_path'=> realpath(CONF_PATH . 'key/rsa_private_key.pem'),
            'ali_public_key_path'=> realpath(CONF_PATH . 'key/rsa_private_key.pem'),
        );

        self::common_pay('alipay',$config,$order);
    }

    /**
     * 财付通付款接口
     */
    private function  ten_pay($order){
        $config = array(
            'key'=> '33182060802321342830012253725443',
            'partner'=> '0000000202'
        );
        self::common_pay('tenpay',$config,$order);
    }

    /**
     * 统一挑起支付信息
     * @param $type
     * @param $config
     * @param $order
     */
    private function common_pay($type,$config,$order){
        $pay = new Pay($type, $config);
        $vo = new Param();
        $vo->setBody($order['body'])
            ->setFee($order['fee']) //支付金额
            ->setOrderNo($order['order_id'])
            ->setTitle($order['title'])
            ->setCallback(DOMAIN.'api.php/pay/notify.html')
            ->setUrl(DOMAIN.'html/order/list.html')
            ->setParam(array('order_msg' => isset($order['msg'])?$order['msg']:"goods1业务订单号"));
        echo $pay->buildRequestForm($vo);
    }
} 