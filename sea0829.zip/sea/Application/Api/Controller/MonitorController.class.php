<?php

namespace Api\Controller;

/**
 * 视频监控管理
 * Class MonitorController
 * @package Api\Controller
 */
class MonitorController extends ApiController
{

    // TODO 视频监控处理
}