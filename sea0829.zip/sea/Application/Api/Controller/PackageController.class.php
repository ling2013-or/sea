<?php
/**
 * 套餐列表
 * User: Administrator
 * Date: 2016/8/23
 * Time: 17:49
 */

namespace Api\Controller;


class PackageController extends ApiController{
    /**
     * 套餐列表
     */
    public function lists()
    {
        //查询条件
        $m = M('Goods');
        //已上架商品
        $map['status'] = 1;
        $map['goods_type'] = 1;

        //按照产品名称搜索
        if (isset($this->data['name']) && $this->data['name'] !== '') {
            $map['name'] = array('LIKE', '%' . $this->data['name'] . '%');
        }

        //按照浏览量搜索
        if (isset($this->data['view']) && !empty($this->data['view'])) {
            $map['browse'] = $this->data['view'];
        }

        //计算分页
        if (isset($this->data['page']) && intval($this->data['page']) > 0) {
            $this->page = intval($this->data['page']);
        }
        if (isset($this->data['page_size']) && intval($this->data['page_size']) > 0) {
            $this->page_size = intval($this->data['page_size']);
        }
        $limit = ($this->page - 1) * $this->page_size . ',' . $this->page_size;

        //获取总条数
        $count = $m->where($map)->count();

        //获取数据
        $res = $m->field('*')
            ->where($map)->order('goods_star DESC')
            ->limit($limit)->select();
        foreach ($res as $key => $val) {
            $res[$key]['picture_more'] = json_decode($val['picture_more'], true);
        }
        $data = array(
            'page' => $this->page,
            'count' => $count,
            'list' => $res ? $res : '',
        );

        //返回数据
        if ($res) {
            //获取轮播图片
            $carousel = $this->getCarousel(CONTROLLER_NAME,ACTION_NAME);
            $data = array_merge($data,$carousel);
            $this->apiReturn(0, '成功', $data);
        } else {
            $this->apiReturn(46301, '暂无农作物信息');
        }
    }
} 