<?php
//000000000000a:2:{s:8:"carousel";a:1:{s:3:"img";N;}s:3:"num";i:1;}
?>