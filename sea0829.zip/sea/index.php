<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/8/7
 * Time: 17:06
 */
//readfile('./web/html/view/index.html');
header('location:./web/html/view/index.html');