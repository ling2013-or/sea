<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/8/4
 * Time: 15:46
 */

// 引入框架入口文件
header('location:../doc/_book/index.html');