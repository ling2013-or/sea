<?php
/**
 * 接口管理主入口
 */
// 开启调试模式 建议开发阶段开启 部署阶段注释或者设为false
define('APP_DEBUG', true);

// 应用模式
define('APP_MODE', 'api');

// 绑定模块
define('BIND_MODULE', 'Api');

// 定义应用目录
define('APP_PATH', '../Application/');

// 缓存存放目录
define('RUNTIME_PATH', '../Runtime/');

// 域名
define('DOMAIN', 'http://sea.com/web/');

// 引入框架入口文件
require '../ThinkPHP/ThinkPHP.php';